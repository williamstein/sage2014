sagemath-ext
============

Final project for UW's MATH 480 with William Stein. A Chrome extension for working with Sage Math.
